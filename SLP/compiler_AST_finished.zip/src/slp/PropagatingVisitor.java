package slp;

/** An interface for a propagating AST visitor.
 * The visitor passes down objects of type <code>DownType</code>
 * and propagates up objects of type <code>UpType</code>.
 */
public interface PropagatingVisitor<DownType,UpType> {
	public UpType visit(UnaryOpExpr expr, DownType d);
	public UpType visit(BinaryOpExpr expr, DownType d);
	public UpType visit(Program expr, DownType d);
	public UpType visit(Class expr, DownType d);
	public UpType visit(Field expr, DownType d);
	public UpType visit(Formal expr, DownType d);
	public UpType visit(Type expr, DownType d);
	public UpType visit(Method expr, DownType d);
	public UpType visit(AssignStmt stmt, DownType d);
	public UpType visit(ReturnStmt stmt, DownType d);
	public UpType visit(StaticCall expr, DownType d);
	public UpType visit(VirtCall expr, DownType d);
	public UpType visit(VarLocation expr, DownType d);
	public UpType visit(ArrayLocation expr, DownType d);
	public UpType visit(CallStmt stmt, DownType d);
	public UpType visit(StmtList stmt, DownType d);
	public UpType visit(IfStmt stmt, DownType d);
	public UpType visit(WhileStmt stmt, DownType d);
	public UpType visit(BreakStmt stmt, DownType d);
	public UpType visit(ContinueStmt stmt, DownType d); 
	public UpType visit(LocalVarStmt stmt, DownType d);
	public UpType visit(ThisExpr expr, DownType d);
	public UpType visit(NewClassExpr expr, DownType d);
	public UpType visit(NewArrayExpr expr, DownType d);
	public UpType visit(LengthExpr expr, DownType d);
	public UpType visit(LiteralExpr expr, DownType d);
}